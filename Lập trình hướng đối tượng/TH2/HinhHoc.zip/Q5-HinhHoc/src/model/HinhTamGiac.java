/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhTamGiac implements HinhHoc2D{
    private double a;
    private double b;
    private double c;
    private int soDinh = 3;
    private int soCanh = 3;

    //constructor
    public HinhTamGiac(){
        
    }
    public HinhTamGiac(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    //input
    public void nhapHinhTamGiac(){
        Scanner in = new Scanner(System.in);
        System.out.print("Nhap canh thu nhat: ");
        a = Double.parseDouble(in.nextLine());
        System.out.print("Nhap canh thu hai: ");
        b = Double.parseDouble(in.nextLine());
        System.out.print("Nhap canh thu ba: ");
        c = Double.parseDouble(in.nextLine());
    }
    
    //getter
    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }

    public int getSoDinh() {
        return soDinh;
    }

    public int getSoCanh() {
        return soCanh;
    }

    //setter
    public void setA(double a) {
        this.a = a;
    }

    public void setB(double b) {
        this.b = b;
    }

    public void setC(double c) {
        this.c = c;
    }

    public void setSoDinh(int soDinh) {
        this.soDinh = soDinh;
    }

    public void setSoCanh(int soCanh) {
        this.soCanh = soCanh;
    }
    
    
    //override
    @Override
    public double tinhChuVi() {
        return a + b + c;
    }

    @Override
    public double tinhDienTich() {
        double p = tinhChuVi() / 2.0;
        return Math.sqrt((a+b+c) * (a+b-c) * (b+c-a) * (c+a-b));
    }

    @Override
    public int tinhSoDinh() {
        return soDinh;
    }

    @Override
    public int tinhSoCanh() {
        return soCanh;
    }
    
}