/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HInhTron implements HinhHoc2D{
    private double r;
    private int soDinh = 0;
    private int soCanh = 0;
    
    //constructor

    public HInhTron() {
    }

    public HInhTron(double r) {
        this.r = r;
    }
    
    //input
    
    public void nhapHinhTron(){
        Scanner in = new Scanner (System.in);
        System.out.print("Nhap ban kinh hinh tron:");
        r = Double.parseDouble(in.nextLine());
    }
    
    //getter

    public double getR() {
        return r;
    }

    public int getSoDinh() {
        return soDinh;
    }

    public int getSoCanh() {
        return soCanh;
    }
    
    //setter

    public void setR(double r) {
        this.r = r;
    }

    public void setSoDinh(int soDinh) {
        this.soDinh = soDinh;
    }

    public void setSoCanh(int soCanh) {
        this.soCanh = soCanh;
    }
    
    
    @Override
    public double tinhChuVi() {
        return Math.PI * r;
    }

    @Override
    public double tinhDienTich() {
        return Math.PI *r*r;
    }

    @Override
    public int tinhSoDinh() {
        return soDinh;
    }

    @Override
    public int tinhSoCanh() {
        return soCanh;
    }
    
}
