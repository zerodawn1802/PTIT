/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhThoi extends HinhTuGiac implements HinhHoc2D{
    private double canh;
    private double duongCheoLon;
    private double duongCheoNho;
    
    //constructor

    public HinhThoi() {
    }

    public HinhThoi(double canh, double duongCheoLon, double duongCheoNho) {
        this.canh = canh;
        this.duongCheoLon = duongCheoLon;
        this.duongCheoNho = duongCheoNho;
    }

    //input
    public void nhapHinhThoi(){
        Scanner in = new Scanner(System.in);
        System.out.print("Nhap canh hinh thoi: ");
        canh = Double.parseDouble(in.nextLine());
        System.out.print("Nhap duong cheo lon hinh thoi: ");
        duongCheoLon = Double.parseDouble(in.nextLine());
        System.out.print("Nhap duong cheo nho hinh thoi: ");
        duongCheoNho = Double.parseDouble(in.nextLine());
    }
    //getter

    public double getCanh() {
        return canh;
    }

    public double getDuongCheoLon() {
        return duongCheoLon;
    }

    public double getDuongCheoNho() {
        return duongCheoNho;
    }
    
    public void setCanh(double canh) {
        this.canh = canh;
    }

    public void setDuongCheoLon(double duongCheoLon) {
        this.duongCheoLon = duongCheoLon;
    }

    public void setDuongCheoNho(double duongCheoNho) {
        this.duongCheoNho = duongCheoNho;
    }

    @Override
    public double tinhChuVi() {
        return canh*4.0;
    }

    @Override
    public double tinhDienTich() {
        return 1.0/2.0 * duongCheoLon * duongCheoNho;
    }

    @Override
    public int tinhSoDinh() {
        return soDinh;
    }

    @Override
    public int tinhSoCanh() {
        return soCanh;
    }
    
}
