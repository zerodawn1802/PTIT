/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author tris1702
 */
public class HinhTuGiac {
    protected int soDinh = 4;
    protected int soCanh = 4;

    public int getSoDinh() {
        return soDinh;
    }

    public int getSoCanh() {
        return soCanh;
    }

    public void setSoDinh(int soDinh) {
        this.soDinh = soDinh;
    }

    public void setSoCanh(int soCanh) {
        this.soCanh = soCanh;
    }
    
    
}
