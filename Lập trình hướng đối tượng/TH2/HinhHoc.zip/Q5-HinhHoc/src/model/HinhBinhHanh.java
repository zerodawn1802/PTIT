/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhBinhHanh extends HinhTuGiac implements HinhHoc2D{
    private double a;
    private double b;
    private double chieuCao;
    
    //constructor

    public HinhBinhHanh() {
    }

    public HinhBinhHanh(double a, double b, double chieuCao) {
        this.a = a;
        this.b = b;
        this.chieuCao = chieuCao;
    }
    
    //getter

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getChieuCao() {
        return chieuCao;
    }
    
    //setter

    public void setA(double a) {
        this.a = a;
    }

    public void setB(double b) {
        this.b = b;
    }

    public void setChieuCao(double chieuCao) {
        this.chieuCao = chieuCao;
    }
    
    
    //input
    
    public void nhapHinhBinhHanh(){
        Scanner in = new Scanner(System.in);
        System.out.print("Nhap canh lon: ");
        a = Double.parseDouble(in.nextLine());
        System.out.println("Nhap canh nho:");
        b = Double.parseDouble(in.nextLine());
        System.out.println("Nhap chieu cao vuong goc voi canh lon:");
        chieuCao = Double.parseDouble(in.nextLine());
    }
    
    @Override
    public double tinhChuVi() {
        return (a+b)*2.0;
    }

    @Override
    public double tinhDienTich() {
        return a*chieuCao;
    }

    @Override
    public int tinhSoDinh() {
        return soDinh;
    }

    @Override
    public int tinhSoCanh() {
        return soCanh;
    }
    
    
    
}
