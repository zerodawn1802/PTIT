/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhCau implements HinhHoc3D{
    private double r;
    private int soDinh = 0;
    private int soCanh = 0;
    //constructor

    public HinhCau() {
    }

    public HinhCau(double r) {
        this.r = r;
    }
    
    //input
    public void nhapHinhCau(){
        Scanner in = new Scanner(System.in);
        System.out.println("Nhap ban kinh cho hinh cau: ");
        r = Double.parseDouble(in.nextLine());
    }
    
    //getter
    public double getR() {
        return r;
    }

    public int getSoDinh() {
        return soDinh;
    }

   
    public int getSoCanh() {    
        return soCanh;
    }
    //setter

    public void setR(double r) {
        this.r = r;
    }

    public void setSoDinh(int soDinh) {
        this.soDinh = soDinh;
    }

    public void setSoCanh(int soCanh) {
        this.soCanh = soCanh;
    }
    

    @Override
    public double tinhTheTich() {
        return 4.0*Math.PI*r*r*r/3.0;
    }

    @Override
    public double tinhDienTichXungQuanh() {
        return 4.0*Math.PI*r*r;
    }
}
