/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhTru implements HinhHoc3D{
    private double r;
    private double h;
    
    //constructor

    public HinhTru() {
    }

    public HinhTru(double r, double h) {
        this.r = r;
        this.h = h;
    }
    
    //input
    public void nhapHinhTru(){
        Scanner in = new Scanner (System.in);
        System.out.println("Nhap ban kinh day: ");
        r = Double.parseDouble(in.nextLine());
        System.out.println("Nhap chieu cao: ");
        h = Double.parseDouble(in.nextLine());
    }
    
    //getter

    public double getR() {
        return r;
    }

    public double getH() {
        return h;
    }
    //setter

    public void setR(double r) {
        this.r = r;
    }

    public void setH(double h) {
        this.h = h;
    }
    
    
    @Override
    public double tinhTheTich() {
        return Math.PI*r*r*h;
    }

    @Override
    public double tinhDienTichXungQuanh() {
        return 2.0*Math.PI*r*h;
    }
    public double tinhDienTichToanPhan() {
        return tinhDienTichXungQuanh() + 2.0*(Math.PI*r);
    }
}
