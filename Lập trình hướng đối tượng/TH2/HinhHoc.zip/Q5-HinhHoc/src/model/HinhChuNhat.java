/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhChuNhat extends HinhTuGiac implements HinhHoc2D{
    private double dai;
    private double rong;
    //constructor
    public HinhChuNhat() {
    }

    public HinhChuNhat(double dai, double rong) {
        this.dai = dai;
        this.rong = rong;
    }
    
    //input
    
    public void nhapHinhChuNhat(){
        Scanner in = new Scanner(System.in);
        System.out.print("Nhap chieu dai: ");
        dai = Double.parseDouble(in.nextLine());
        System.out.print("Nhap chieu rong: ");
        rong = Double.parseDouble(in.nextLine());
    }
    
    
    //getter
    public double getDai() {
        return dai;
    }

    public double getRong() {
        return rong;
    }

    
    //setter

    public void setDai(double dai) {
        this.dai = dai;
    }

    public void setRong(double rong) {
        this.rong = rong;
    }
    
    
    @Override
    public double tinhChuVi() {
        return (dai+rong) * 2.0;
    }

    @Override
    public double tinhDienTich() {
        return dai*rong;
    }

    @Override
    public int tinhSoDinh() {
        return soDinh;
    }

    @Override
    public int tinhSoCanh() {
        return soCanh;
    }
    
}
