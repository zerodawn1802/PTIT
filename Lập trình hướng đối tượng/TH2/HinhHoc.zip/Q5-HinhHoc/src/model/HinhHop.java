/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhHop implements HinhHoc3D{
    private double chieuDai;
    private double chieuRong;
    private double chieuCao;
    
    //constructor

    public HinhHop() {
    }

    public HinhHop(double chieuDai, double chieuRong, double chieuCao) {
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
        this.chieuCao = chieuCao;
    }
    
    //input
    public void nhapHinhChuNhat(){
        Scanner in = new Scanner(System.in);
        System.out.print("Nhap chieu dai: ");
        chieuDai = Double.parseDouble(in.nextLine());
        System.out.print("Nhap chieu rong: ");
        chieuRong = Double.parseDouble(in.nextLine());
        System.out.print("Nhap chieu cao: ");
        chieuCao = Double.parseDouble(in.nextLine());
    }
    
    //getter

    public double getChieuDai() {
        return chieuDai;
    }

    public double getChieuRong() {
        return chieuRong;
    }

    public double getChieuCao() {
        return chieuCao;
    }
    
    //setter

    public void setChieuDai(double chieuDai) {
        this.chieuDai = chieuDai;
    }

    public void setChieuRong(double chieuRong) {
        this.chieuRong = chieuRong;
    }

    public void setChieuCao(double chieuCao) {
        this.chieuCao = chieuCao;
    }

    @Override
    public double tinhTheTich() {
        return chieuDai * chieuRong * chieuCao;
    }

    @Override
    public double tinhDienTichXungQuanh() {
        return 2.0*chieuCao*(chieuDai + chieuRong);
    }
    
    public double tinhDienTichToanPhan(){
        return tinhDienTichXungQuanh() + (chieuCao+chieuRong)*2.0;
    }
    
}
