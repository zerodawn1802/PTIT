/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Scanner;

/**
 *
 * @author tris1702
 */
public class HinhVuong extends HinhTuGiac implements HinhHoc2D{
    private double canh;
    //constructor

    public HinhVuong() {
    }
    
    public HinhVuong(double canh) {
        this.canh = canh;
    }
    
    //input
    public void nhapHinhVuong(){
        Scanner in = new Scanner(System.in);
        System.out.print("Nhap canh cua hinh vuong: ");
        canh = Double.parseDouble(in.nextLine());
    }
    
    //getter

    public double getCanh() {
        return canh;
    }
    //setter

    public void setCanh(double canh) {
        this.canh = canh;
    }
    
    
    @Override
    public double tinhChuVi() {
        return canh*4.0;
    }

    @Override
    public double tinhDienTich() {
        return canh*canh;
    }

    @Override
    public int tinhSoDinh() {
        return soDinh;
    }

    @Override
    public int tinhSoCanh() {
        return soCanh;
    }
    
}
